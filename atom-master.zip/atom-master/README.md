# SGB
SGB is a discord bot made for awesome general stuffs.It is made with discord.js

