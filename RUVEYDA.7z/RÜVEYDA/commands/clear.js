module.exports.run = async (bot,msg,args) =>{
 
    
}
    
    module.exports.config = {
        command : "clear",
        description : "Clear the messages in that channel according to the no. given.."
    }
    
