module.exports.run = async(bot,msg,args) =>{

}


module.exports.config = {
    command : "ping",
    description : "See the bots responce time"
}

